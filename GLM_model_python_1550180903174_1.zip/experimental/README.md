Outputting model information in JSON is an experimental feature and we appreciate any feedback.
The contents of this folder may change with another version of H2O.
